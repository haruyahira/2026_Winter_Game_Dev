#pragma once
#include "MagicBase.h"
#include <memory>
// ���ǉ��F��p�̕`��V�X�e��
#include "../../Renderer/ModelMaterial.h"
#include "../../Renderer/ModelRenderer.h"

class FireBall : public MagicBase
{
public:
    FireBall(void);
    virtual ~FireBall(void);

    void Init(void) override;
    void Update(void) override;
    void Draw(void) override;
    void Fire(const Transform& spawnTransform, VECTOR dir) override;
    bool isDestroy(void) override;

private:
    VECTOR moveDir_;
    float lifeTimer_;

    // ���ǉ��F�V�F�[�_�[�ƃ����_���[
    std::unique_ptr<ModelMaterial> material_;
    std::unique_ptr<ModelRenderer> renderer_;
};
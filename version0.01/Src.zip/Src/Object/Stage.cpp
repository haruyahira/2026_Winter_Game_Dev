#include <vector>
#include <map>
#include <DxLib.h>
#include "../Utility/AsoUtility.h"
#include "../Manager/SceneManager.h"
#include "../Manager/ResourceManager.h"
#include "Charactor/Player/Player.h"
#include "Charactor/Enemy/BossEnemy.h"
#include "Common/Collider.h"
#include "Common/Transform.h"
#include "Destroyer.h"
#include "Planet.h"
#include "Skull.h"
#include "Stage.h"

Stage::Stage(Player& player, Destroyer& destroyer, BossEnemy& centaur)
	:
	resMng_(ResourceManager::GetInstance()),
	player_(player), destroyer_(destroyer), centaur_(centaur)
{
	activeName_ = NAME::MAIN_PLANET;
	step_ = 0.0f;
}

Stage::~Stage(void)
{
	// �f��
	planets_.clear();

	// �[���I�u�W�F�N�g
	skulls_.clear();
}

void Stage::Init(void)
{
	MakeMainStage();
	
	MakeEnvironment();
	
	step_ = -1.0f;
}

void Stage::Update(void)
{
	// �f��
	for (const auto& s : planets_)
	{
		s.second->Update();
	}

	// �[���I�u�W�F�N�g
	for (const auto& s : skulls_)
	{
		s->Update();
	}
}

void Stage::Draw(void)
{
	// �f��
	for (const auto& s : planets_)
	{
		s.second->Draw();
	}

	// �[���I�u�W�F�N�g
	for (const auto& s : skulls_)
	{
		s->Draw();
	}
}

void Stage::ChangeStage(NAME type)
{
	activeName_ = type;

	// �Ώۂ̃X�e�[�W���擾����
	activePlanet_ = GetPlanet(activeName_);

	// �X�e�[�W�̓����蔻����v���C���[�ɐݒ�
	player_.ClearCollider();
	player_.AddCollider(activePlanet_.lock()->GetTransform().collider);
	destroyer_.ClearCollider();
	destroyer_.AddCollider(activePlanet_.lock()->GetTransform().collider);
	centaur_.ClearCollider();
	centaur_.AddCollider(activePlanet_.lock()->GetTransform().collider);

	step_ = TIME_STAGE_CHANGE;
}

std::weak_ptr<Planet> Stage::GetPlanet(NAME type)
{
	if (planets_.count(type) == 0)
	{
		return nullPlanet;
	}

	return planets_[type];
}

void Stage::MakeMainStage(void)
{
	// �ŏ��̘f��
	//------------------------------------------------------------------------------
	Transform planetTrans;
	planetTrans.SetModel(
		resMng_.LoadModelDuplicate(ResourceManager::SRC::MAIN_PLANET));
	planetTrans.scl = AsoUtility::VECTOR_ONE;
	planetTrans.quaRot = Quaternion();
	planetTrans.pos = { 0.0f, -760.0f, 0.0f };

	// �����蔻��(�R���C�_)�쐬
	planetTrans.MakeCollider(Collider::TYPE::STAGE);

	planetTrans.Update();

	NAME name = NAME::MAIN_PLANET;
	std::shared_ptr<Planet> planet =
		std::make_shared<Planet>(
			name, Planet::TYPE::GROUND, planetTrans);
	planet->Init();
	planets_.emplace(name, std::move(planet));
	//------------------------------------------------------------------------------
}

void Stage::MakeEnvironment(void)
{
	auto skull = std::make_shared<Skull>();
	skull->Init();
	skull->SetPos({ -300.0f, -30.0f, 500.0f });
	skulls_.emplace_back(std::move(skull));

	skull = std::make_shared<Skull>();
	skull->Init();
	skull->SetPos({ 250.0f, -60.0f, 900.0f });
	skulls_.emplace_back(std::move(skull));

	skull = std::make_shared<Skull>();
	skull->Init();
	skull->SetPos({ -20.0f, -45.0f, 1600.0f });
	skulls_.emplace_back(std::move(skull));
}

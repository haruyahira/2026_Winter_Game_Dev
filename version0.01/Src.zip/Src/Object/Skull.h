#pragma once
#include "../Common/Quaternion.h"
#include "ActorBase.h"
class ModelMaterial;
class ModelRenderer;

class Skull 
	: public ActorBase
{

public :

	// �R���X�g���N�^
	Skull(void);

	// �f�X�g���N�^
	~Skull(void);

	void Init(void) override;
	void Update(void) override;
	void Draw(void) override;

	void SetPos(VECTOR pos);

private:

	// ���f���`��p�p
	std::unique_ptr<ModelMaterial> material_;
	std::unique_ptr<ModelRenderer> renderer_;


	float sinTime_;
	float offset_;

};


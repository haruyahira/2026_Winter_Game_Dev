#include <DxLib.h>
#include "../Utility/AsoUtility.h"
#include "../Manager/SceneManager.h"
#include "../Manager/Camera.h"
#include "../Manager/InputManager.h"
#include "../Object/Common/Capsule.h"
#include "../Object/Common/Collider.h"
#include "../Object/Charactor/Player/Player.h"
#include "../Object/Charactor/Enemy/BossEnemy.h"
#include "../Object/SkyDome.h"
#include "../Object/Stage.h"
#include "../Object/Destroyer.h"
#include "GameScene.h"

GameScene::GameScene(void)
{
	player_ = nullptr;
	destroyer_ = nullptr;
	skyDome_ = nullptr;
	stage_ = nullptr;
}

GameScene::~GameScene(void)
{
}

void GameScene::Init(void)
{

	// �v���C���[
	player_ = std::make_unique<Player>();
	player_->Init();
	player_->SetSpawnFunc([this](std::unique_ptr<ActorBase> actor) {
		this->dynamicActors_.push_back(std::move(actor));
		});
	
	// �j���
	destroyer_ = std::make_unique<Destroyer>();
	destroyer_->Init();

	// �j���
	centaur_ = std::make_unique<BossEnemy>();
	centaur_->Init();

	// �X�e�[�W
	stage_ = std::make_unique<Stage>(*player_, *destroyer_, *centaur_);
	stage_->Init();

	// �X�e�[�W�̏����ݒ�
	stage_->ChangeStage(Stage::NAME::MAIN_PLANET);

	// �X�J�C�h�[��
	skyDome_ = std::make_unique<SkyDome>(player_->GetTransform());
	skyDome_->Init();

	mainCamera.SetFollow(&player_->GetTransform());
	mainCamera.ChangeMode(Camera::MODE::FOLLOW);

}

void GameScene::Update(void)
{

	// �V�[���J��
	InputManager& ins = InputManager::GetInstance();
	if (ins.IsTrgDown(KEY_INPUT_1))
	{
		SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::TITLE);
	}

	skyDome_->Update();

	stage_->Update();

	player_->Update();

	destroyer_->Update();

	centaur_->Update();

	for (auto it = dynamicActors_.begin(); it != dynamicActors_.end(); )
	{
		(*it)->Update();

		if ((*it)->isDestroy())
		{
			it = dynamicActors_.erase(it); // ���ŁI
		}
		else
		{
			++it;
		}
	}
}

void GameScene::Draw(void)
{

	// �w�i
	skyDome_->Draw();
	stage_->Draw();
	
	player_->Draw();
	destroyer_->Draw();
	centaur_->Draw();

	for (auto& actor : dynamicActors_)
	{
		actor->Draw();
	}

	// �w���v
	DrawFormatString(840, 20, 0x000000, "�ړ��@�@�FWASD");
	DrawFormatString(840, 40, 0x000000, "�J�����@�F���L�[");
	DrawFormatString(840, 60, 0x000000, "�_�b�V���F�EShift");
	DrawFormatString(840, 80, 0x000000, "�W�����v�FSPACE");

	// ���Q�[�����ɑ��݂��Ă��閂�@�̐�����ʍ���ɕ\������
	DrawFormatString(20, 20, 0xffffff, "���@�̐��F%d", dynamicActors_.size());
	if (!dynamicActors_.empty())
	{
		auto pos = dynamicActors_[0]->GetTransform().pos;
		DrawFormatString(20, 40, 0xffffff, "���@�̍��W: X:%.1f Y:%.1f Z:%.1f", pos.x, pos.y, pos.z);
	}
	auto playerPos = player_->GetTransform().pos;
	DrawFormatString(20, 60, 0xffffff, "���W: X:%.1f Y:%.1f Z:%.1f", playerPos.x, playerPos.y, playerPos.z);
}
